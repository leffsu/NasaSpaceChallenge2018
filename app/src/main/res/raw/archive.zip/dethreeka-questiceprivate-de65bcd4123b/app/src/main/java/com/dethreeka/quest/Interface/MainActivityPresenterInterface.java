package com.dethreeka.quest.Interface;

import android.app.Activity;

public interface MainActivityPresenterInterface {

    void continueClick();
    void play2dClick();
    void play3dClick();
    void settingsClick();
    void exitClick();
}
