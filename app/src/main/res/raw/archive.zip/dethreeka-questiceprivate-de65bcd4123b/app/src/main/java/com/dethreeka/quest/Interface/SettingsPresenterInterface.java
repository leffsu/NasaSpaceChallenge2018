package com.dethreeka.quest.Interface;

public interface SettingsPresenterInterface {
}
