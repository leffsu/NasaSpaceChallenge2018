package com.dethreeka.quest.Interface;

public interface Play2DPresenterInterface {
}
