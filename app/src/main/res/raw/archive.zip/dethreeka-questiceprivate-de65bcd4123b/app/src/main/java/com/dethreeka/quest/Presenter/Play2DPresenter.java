package com.dethreeka.quest.Presenter;

public class Play2DPresenter {

}
