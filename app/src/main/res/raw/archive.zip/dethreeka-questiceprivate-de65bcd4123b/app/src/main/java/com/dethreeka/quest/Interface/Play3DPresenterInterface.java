package com.dethreeka.quest.Interface;

public interface Play3DPresenterInterface {
}
