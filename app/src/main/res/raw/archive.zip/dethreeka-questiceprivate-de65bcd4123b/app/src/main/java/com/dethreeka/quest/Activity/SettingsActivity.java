package com.dethreeka.quest.Activity;

import android.support.v7.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

}
