package com.dethreeka.quest.Presenter;

public class Play3DPresenter {
}
