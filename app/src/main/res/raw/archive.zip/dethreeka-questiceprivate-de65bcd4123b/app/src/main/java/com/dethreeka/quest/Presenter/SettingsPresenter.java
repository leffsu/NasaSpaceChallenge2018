package com.dethreeka.quest.Presenter;

public class SettingsPresenter {
}
